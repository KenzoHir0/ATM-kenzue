﻿Imports System.Security.Policy

Public Class Form4
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Choice_TextChanged(sender As Object, e As EventArgs) Handles Choice.TextChanged
        Dim num As Integer
        Integer.TryParse(Choice.Text, num)
        If num = 1 Then
            Dim amount As Double
            Double.TryParse(TextBox1.Text, amount)
            If amount > 0 Then
                If User_name.Text = "Heherson" Then
                    Dim balance As Double
                    Double.TryParse(My.Computer.FileSystem.ReadAllText("D:\downloads\Vs\Heherson\Heherson\Bank-of-Pandora\user1_balance.txt"), balance)
                    My.Computer.FileSystem.WriteAllText("D:\downloads\Vs\Heherson\Heherson\Bank-of-Pandora\user1_balance.txt", Str(balance + amount), False)
                    My.Computer.FileSystem.WriteAllText("D:\downloads\Vs\Heherson\Heherson\Bank-of-Pandora\user1_mini_statement.txt", Environment.NewLine & System.DateTime.Today.Month.ToString & "/" & System.DateTime.Today.Day.ToString & "/" & System.DateTime.Today.Year.ToString & "     " & System.DateTime.Now.Hour & ":" & System.DateTime.Now.Minute & "     Deposit     " & "$" & Str(amount), True)
                    User_name.Text = ""
                    Form2.User_name.Text = " "
                    Form2.User_name.Text = "Heherson"
                    TextBox1.Text = ""
                    Me.Visible = False
                    Form2.Show()
                ElseIf User_name.Text = "Aljane" Then
                    Dim balance As Double
                    Double.TryParse(My.Computer.FileSystem.ReadAllText("D:\downloads\Vs\Heherson\Heherson\Bank-of-Pandora\user2_balance.txt"), balance)
                    My.Computer.FileSystem.WriteAllText("D:\downloads\Vs\Heherson\Heherson\Bank-of-Pandora\user2_balance.txt", Str(balance + amount), False)
                    My.Computer.FileSystem.WriteAllText("D:\downloads\Vs\Heherson\Heherson\Bank-of-Pandora\user2_mini_statement.txt", Environment.NewLine & System.DateTime.Today.Month.ToString & "/" & System.DateTime.Today.Day.ToString & "/" & System.DateTime.Today.Year.ToString & "     " & System.DateTime.Now.Hour & ":" & System.DateTime.Now.Minute & "     Deposit     " & "$" & Str(amount), True)
                    User_name.Text = ""
                    Form2.User_name.Text = " "
                    Form2.User_name.Text = "Aljane"
                    TextBox1.Text = ""
                    Me.Visible = False
                    Form2.Show()
                Else
                    Dim warn As String = MsgBox("Invalid amount...", vbOKOnly)
                    TextBox1.Text = ""
                    TextBox1.Select()
                End If
            End If
        ElseIf num = 2 Then
            User_name.Text = ""
            TextBox1.Text = ""
            Me.Visible = False
            Form2.Show()
        End If
        Choice.Text = ""
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub User_name_TextChanged(sender As Object, e As EventArgs) Handles User_name.TextChanged
        Label4.Text = "USER: " & User_name.Text
    End Sub

End Class