﻿Public Class Form8
    Private Sub Form7_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub User_name_TextChanged(sender As Object, e As EventArgs) Handles User_name.TextChanged
        Label4.Text = User_name.Text
        ListBox1.Items.Clear()
        ListBox1.Items.Add("LAST 5 TRANSACTIONS:")
        If User_name.Text = "Heherson" Then
            Dim history = My.Computer.FileSystem.ReadAllText("D:\downloads\Vs\Heherson\Heherson\Bank-of-Pandora\user1_transaction.txt").Split(New String() {Environment.NewLine}, StringSplitOptions.None)
            For i = 0 To history.Length() - 1
                If ListBox1.Items.Count() < 6 Then
                    ListBox1.Items.Add(history(history.Length() - 1 - i))
                End If
            Next
        ElseIf User_name.Text = "Aljane" Then
            Dim history = My.Computer.FileSystem.ReadAllText("D:\downloads\Vs\Heherson\Heherson\Bank-of-Pandora\user2_transaction.txt").Split(New String() {Environment.NewLine}, StringSplitOptions.None)
            For i = 0 To history.Length() - 1
                If ListBox1.Items.Count() < 6 Then
                    ListBox1.Items.Add(history(history.Length() - 1 - i))
                End If
            Next
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If User_name.Text = "Heherson" Then
            Form2.User_name.Text = ""
            Form2.User_name.Text = "Heherson"
            Visible = False
            Form2.Show()
        ElseIf User_name.Text = "Aljane" Then
            Form2.User_name.Text = ""
            Form2.User_name.Text = "Aljane"
            Visible = False
            Form2.Show()
        End If
        User_name.Text = ""
    End Sub
End Class