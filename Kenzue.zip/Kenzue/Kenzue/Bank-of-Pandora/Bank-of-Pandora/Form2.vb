﻿Public Class Form2
    Dim Choices_text As String
    Dim Choices_text1 As String
    Dim user_balance As String
    Dim state As Integer = 0
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Choice_TextChanged(sender As Object, e As EventArgs) Handles Choice.TextChanged
        Dim num As Double
        Double.TryParse(Choice.Text, num)
        If state = 0 Then
            If num = 8 Then
                Form1.User_name.Text = "_"
                Me.Visible = False
                Form1.Show()
            ElseIf num = 1 Then
                Form4.User_name.Text = User_name.Text
                Me.Visible = False
                Form4.Show()
            ElseIf num = 2 Then
                Form5.User_name.Text = User_name.Text
                Me.Visible = False
                Form5.Show()
            ElseIf num = 5 Then
                Form7.User_name.Text = User_name.Text
                Me.Visible = False
                Form7.Show()
            ElseIf num = 4 Then
                Form6.User_name.Text = User_name.Text
                Me.Visible = False
                Form6.Show()
            ElseIf num = 6 Then
                Me.Visible = False
                Form3.Show()
                Form3.User_name.Text = User_name.Text
            ElseIf num = 7 Then
                Me.Visible = False
                Form8.Show()
                Form8.User_name.Text = User_name.Text
            ElseIf num = 3 Then
                Label1.Text = ""
                Label3.Text = "BALANCE: $" & user_balance & System.Environment.NewLine & System.Environment.NewLine & "1. BACK"
                state = 1
            End If
        ElseIf state = 1 Then
            If num = 1 Then
                Label3.Text = Choices_text
                Label1.Text = Choices_text1
                state = 0
            End If
        End If
        Choice.Text = ""
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub User_name_TextChanged(sender As Object, e As EventArgs) Handles User_name.TextChanged
        Choices_text = Label3.Text
        Choices_text1 = Label1.Text
        Label4.Text = "USER: " & User_name.Text
        If User_name.Text = "Heherson" Then
            user_balance = My.Computer.FileSystem.ReadAllText("D:\downloads\Vs\Heherson\Heherson\Bank-of-Pandora\user1_balance.txt")
        ElseIf User_name.Text = "Aljane" Then
            user_balance = My.Computer.FileSystem.ReadAllText("D:\downloads\Vs\Heherson\Heherson\Bank-of-Pandora\user2_balance.txt")
        End If
    End Sub
End Class