﻿Public Class Form7
    Private Sub Form7_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub User_name_TextChanged(sender As Object, e As EventArgs) Handles User_name.TextChanged
        Label4.Text = User_name.Text
        ListBox1.Items.Clear()
        ListBox1.Items.Add("MINI STATEMENT:")
        If User_name.Text = "Heherson" Then
            Dim history = My.Computer.FileSystem.ReadAllText("D:\downloads\Vs\Heherson\Heherson\Bank-of-Pandora\user1_mini_statement.txt").Split(New String() {Environment.NewLine}, StringSplitOptions.None)
            If history.Length() - 1 > 0 Then
                For i = 1 To history.Length() - 1
                    ListBox1.Items.Add(history(history.Length() - 1 - i))
                Next
            End If
        ElseIf User_name.Text = "Aljane" Then
            Dim history = My.Computer.FileSystem.ReadAllText("D:\downloads\Vs\Heherson\Heherson\Bank-of-Pandora\user2_mini_statement.txt").Split(New String() {Environment.NewLine}, StringSplitOptions.None)
            If history.Length() - 1 > 0 Then
                For i = 1 To history.Length() - 1
                    ListBox1.Items.Add(history(history.Length() - 1 - i))
                Next
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If User_name.Text = "Heherson" Then
            Form2.User_name.Text = ""
            Form2.User_name.Text = "Heherson"
            Visible = False
            Form2.Show()
        ElseIf User_name.Text = "Aljane" Then
            Form2.User_name.Text = ""
            Form2.User_name.Text = "Aljane"
            Visible = False
            Form2.Show()
        End If
        User_name.Text = ""
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ListBox1.Items.Clear()
        ListBox1.Items.Add("MINI STATEMENT:")
        If User_name.Text = "Heherson" Then
            My.Computer.FileSystem.WriteAllText("D:\downloads\Vs\Heherson\Heherson\Bank-of-Pandora\user1_mini_statement.txt", "", False)
        ElseIf User_name.Text = "Aljane" Then
            My.Computer.FileSystem.WriteAllText("D:\downloads\Vs\Heherson\Heherson\Bank-of-Pandora\user2_mini_statement.txt", "", False)
        End If
    End Sub
End Class